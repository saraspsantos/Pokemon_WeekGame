package org.academiadecodigo.teamgreen.pokemon.BattleLogic;

public enum PhysSpec {

    PHYSICAL,
    SPECIAL,
    SELF_STAT_CHANGE,
    OPPO_STAT_CHANGE,
    BOTH_STAT_CHANGE
}
