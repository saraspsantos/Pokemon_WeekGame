package org.academiadecodigo.teamgreen.pokemon;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
