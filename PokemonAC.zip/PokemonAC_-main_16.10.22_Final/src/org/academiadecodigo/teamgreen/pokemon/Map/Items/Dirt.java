package org.academiadecodigo.teamgreen.pokemon.Map.Items;

import org.academiadecodigo.simplegraphics.pictures.Picture;

public class Dirt extends ItemOfMap {


    private Picture picture;

    public Dirt(int x, int y) {
        super(true);
    }

}
