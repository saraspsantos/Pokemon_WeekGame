package org.academiadecodigo.teamgreen.pokemon.Map;

public enum HouseType {

    SMALL,
    MEDIUM,
    LARGE,
    LABORATORY,
    TEMPLE

}