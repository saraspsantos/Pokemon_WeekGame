package org.academiadecodigo.teamgreen.pokemon.Map.Items;

public class blankSpace extends ItemOfMap {

    public blankSpace() {
        super(true);
    }

}