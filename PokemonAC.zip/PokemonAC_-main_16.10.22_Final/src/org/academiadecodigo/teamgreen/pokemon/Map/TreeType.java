package org.academiadecodigo.teamgreen.pokemon.Map;

public enum TreeType {
    SMALL,
    MEDIUM,
    BIG
}
