package org.academiadecodigo.teamgreen.pokemon.Actors;

public enum EnemyType {

    MAGMA_GRUNT,
    AQUA_GRUNT,
    MAGMA_BOSS,
    AQUA_BOSS
}
